#' @title cytof config file for example
#' @docType data
#' @name config
#' @keywords d dataset
#'
NULL

#' @title difference markers dataframe for example
#' @docType data
#' @name deDF
#' @keywords d dataset
#'
NULL

#' @title PCR'meta.csv for example
#' @docType data
#' @name pCRexample
#' @keywords d dataset
#'
NULL
