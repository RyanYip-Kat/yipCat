#' @title cytof config file for example
#' @docType data
#' @name config
#' @keywords d dataset
#'
NULL
